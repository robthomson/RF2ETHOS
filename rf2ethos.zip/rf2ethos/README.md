# rf2touch
Rotorflight 2 Configurator for Ethos - Touch Screen Enabled
