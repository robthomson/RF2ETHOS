return {margin = 5, indent = 15, lineSpacing = 20, listSpacing = {line = 20, field = 170}, tableSpacing = {row = 25, col = 60, header = 20}}
