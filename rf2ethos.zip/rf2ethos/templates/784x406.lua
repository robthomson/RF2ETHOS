return {margin = 0, indent = 15, lineSpacing = 45, listSpacing = {line = 45, field = 465}, tableSpacing = {row = 50, col = 150, header = 45}}

