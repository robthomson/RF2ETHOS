return {margin = 5, indent = 15, lineSpacing = 25, listSpacing = {line = 25, field = 170}, tableSpacing = {row = 25, col = 60, header = 20}}
