return {margin = 5, indent = 15, lineSpacing = 30, listSpacing = {line = 35, field = 220}, tableSpacing = {row = 35, col = 80, header = 27}}
